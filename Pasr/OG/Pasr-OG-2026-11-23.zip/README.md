# Pasr – OG-afbeelding deelpagina stempelkaart (2026-11-23)

| Bestand | Pagina | Taal | Formaat | Alt-tekst |
|---|---|---|---|---|
| `zakelijk-kaart-voorbeeld-nl.png` | `https://pasr.nl/zakelijk/kaart/<kaart-id>/` (voorbeeld) | Nederlands | 1200×630 PNG | Stempelkaart Koffiekaart van Koffiebar De Hoek: 10 stempels voor 1 gratis koffie |

Voorbeeld met verzonnen data (Koffiebar De Hoek, Apeldoorn). Op pasr.nl krijgt elke gepubliceerde stempelkaart een eigen
afbeelding `/og/zakelijk/<kaart-id>.png` in dit ontwerp, met de kleur, het logo, de tekstkleur, de naam, de vakjes en de
beloning van die kaart. Die worden elk uur gemaakt door de Website-workflow (alleen als een kaart veranderd is).

Bron: `tools/make_kaart_pages.py` (render met Pillow, lettertypen in `tools/og/fonts/`) in LRvdLinden/app.lrvdlinden.pasr,
branch `gedeelde-pasr`. Gepubliceerd in `website/og/zakelijk/` (niet in de repo, wordt per build gemaakt).
