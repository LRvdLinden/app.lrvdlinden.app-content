# Pasr OG-afbeeldingen (2026-11-22)

| Bestand | Pagina | Taal | Formaat | Alt-tekst |
|---|---|---|---|---|
| zakelijk-nl.png | https://pasr.nl/zakelijk/ | Nederlands | 1200×630 PNG | Twee digitale stempelkaarten van een koffiebar en een bakkerij, naast de tekst: Gratis digitale stempelkaart voor je zaak |

Bron: repo LRvdLinden/app.lrvdlinden.pasr, `tools/og/zakelijk.html` (renderen met `python3 tools/og/render.py zakelijk`), gepubliceerd als `website/og/zakelijk.png`.
