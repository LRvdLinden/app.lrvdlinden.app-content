# Pasr OG-afbeeldingen (2026-11-22, 2)

| Bestand | Pagina | Taal | Formaat | Alt-tekst |
|---|---|---|---|---|
| home-nl.png | https://pasr.nl/ | Nederlands | 1200x630 PNG | Pasr op een telefoon met een stapel klantenkaarten, naast de tekst: Al je klantenkaarten in één app, voor iPhone, iPad, Apple Watch en Android |
| zakelijk-nl.png | https://pasr.nl/zakelijk/ | Nederlands | 1200x630 PNG | Twee digitale stempelkaarten van een koffiebar en een bakkerij, naast de tekst: Gratis digitale stempelkaart voor je zaak |

Bron home: appstore/source/scenes.html (OG.home) in LRvdLinden/app.lrvdlinden.pasr; zakelijk: tools/og/zakelijk.html.
