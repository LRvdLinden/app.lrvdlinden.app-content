# MV3 og-afbeelding (2026-11-15)

| Bestand | Pagina | Taal | Formaat | Alt-tekst |
| --- | --- | --- | --- | --- |
| home-nl.png | https://mv3.lrvdlinden.app/ | NL | 1200×630 | MV3: tekening van de grijs-oranje Falcon 8X PH-UTL op een gestippelde route, met de tekst “De jet van Max Verstappen, live.” |

Bron: LRvdLinden/app.lrvdlinden.112heli, `mv3/tools/og.html` + `og.py`, uitvoer `mv3/web/og.png`. Website door PixelForges.
