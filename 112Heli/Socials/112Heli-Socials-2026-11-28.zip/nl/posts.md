# 112Heli – Instagram-reel (NL, algemene promotie)

## Reel (1080×1920, 18,6 s, 30 fps, zonder geluid)
Bestand: `reel-1080x1920.mp4`. Cover: `reel-cover-1080x1920.png` (de kop en de knop staan in het midden, zodat ze ook in de 3:4-rasterweergave van je profiel zichtbaar blijven).
Tip: kies in Instagram een rustig muziekje uit de audiobibliotheek; de video heeft bewust geen geluid.

## Posttekst
Hoor je een helikopter? 🚁 Met 112Heli zie je meteen welke het is en waar hij heen gaat.

Live op de kaart: de Lifeliner, de politiehelikopter, de Kustwacht en Defensie. Krijg een melding als er een opstijgt, ook boven je eigen wijk. En de jet van Max Verstappen staat er gewoon tussen.

Kijk nu al mee op 112heli.lrvdlinden.app. De app komt binnenkort in de App Store voor iPhone, iPad, Mac en Apple TV.

#112Heli #Lifeliner #Politiehelikopter #Kustwacht #Hulpdiensten #Helikopter

## Alt-teksten
- reel-1080x1920.mp4: Korte video van 112Heli op een blauwe achtergrond. Eerst de vraag "Hoor je een helikopter?" met een gele Lifeliner en een politiehelikopter, dan vier schermen van de app op een iPhone: de kaart met Lifeliner 3 en zijn route, een melding op het toegangsscherm dat Lifeliner 3 is opgestegen, de lijst met toestellen en de jet van Max Verstappen op de kaart. Aan het eind het app-icoon met "Binnenkort in de App Store" en 112heli.lrvdlinden.app.
- reel-cover-1080x1920.png: Cover met het app-icoon van 112Heli, de tekst "Waar vliegt de Lifeliner nu?", een gele Lifeliner en de knop "Binnenkort in de App Store".
