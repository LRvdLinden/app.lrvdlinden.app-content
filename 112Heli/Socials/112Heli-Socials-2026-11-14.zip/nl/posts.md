# 112Heli – postteksten (NL, algemene promotie)

## Instagram / Facebook (1080×1080 en 1080×1350)
Waar vliegt de Lifeliner nu? En waarom hangt de politiehelikopter boven je wijk? 🚁
Met 112Heli zie je live alles wat voor de hulpdiensten vliegt: Lifeliner, Zulu, Kustwacht en Defensie. Krijg een melding bij opstijgen, zie waar een helikopter landt en volg je eigen zones. Kijk nu al mee op 112heli.lrvdlinden.app, de app komt binnenkort in de App Store.

#112Heli #Lifeliner #Politiehelikopter #Kustwacht #Hulpdiensten #Luchtvaart

## Story / Reels (1080×1920)
Kort: Alles wat vliegt voor de hulpdiensten, live. Link: 112heli.lrvdlinden.app
(Link-sticker: https://112heli.lrvdlinden.app)

## LinkedIn (1200×627)
Bij een groot incident hangen er vaak helikopters in de lucht, maar waar en waarom is lastig te volgen. Daarom bouwde ik 112Heli: een gratis app en website die live laat zien waar de Lifeliners, de politiehelikopter, de Kustwacht en Defensie vliegen. Met meldingen bij opstijgen, de landingsplek en een signaal als er meerdere helikopters op één plek zijn. De app komt binnenkort in de App Store voor iPhone, iPad, Mac en Apple TV; de live kaart staat nu al op https://112heli.lrvdlinden.app

## Alt-teksten
- instagram-1080x1080.png: Banner van 112Heli met een gele Lifeliner en een blauw-witte politiehelikopter op een radar, met de tekst "Alles wat vliegt voor de hulpdiensten. Live." en "Binnenkort in de App Store".
- instagram-1080x1350.png: Banner van 112Heli met een Lifeliner, een politiehelikopter en een Kustwacht-helikopter boven een radar, met de tekst "Alles wat vliegt voor de hulpdiensten. Live.", vier functies en "Binnenkort in de App Store".
- story-1080x1920.png: Staande banner van 112Heli met de tekst "Alles wat vliegt voor de hulpdiensten. Live.", een Lifeliner en een politiehelikopter op een radar en de link 112heli.lrvdlinden.app.
- linkedin-1200x627.png: Banner van 112Heli met de tekst "Alles wat vliegt voor de hulpdiensten. Live.", een Lifeliner en een politiehelikopter op een radar en "Binnenkort in de App Store".
