# 112Heli og-afbeeldingen (2026-11-15, nieuwe huisstijl)

| Bestand | Pagina | Taal | Formaat | Alt-tekst |
| --- | --- | --- | --- | --- |
| home-nl.png | https://112heli.lrvdlinden.app/ | NL | 1200×630 | 112Heli: alles wat vliegt voor de hulpdiensten, live op de kaart |
| kaart-nl.png | https://112heli.lrvdlinden.app/kaart/ | NL | 1200×630 | Live kaart van 112Heli met de Lifeliner, de Zulu en de Kustwacht |
| toestellen-nl.png | https://112heli.lrvdlinden.app/toestellen/ | NL | 1200×630 | Alle toestellen van 112Heli op een rij |

Bron: LRvdLinden/app.lrvdlinden.112heli, `website/og/` (og.html + render.py), uitvoer in `website/web/og/`.
