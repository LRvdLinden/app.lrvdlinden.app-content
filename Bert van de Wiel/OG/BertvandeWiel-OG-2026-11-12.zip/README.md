# OG-afbeeldingen bertvandewiel.nl (2026-11-12)

| Bestand | Pagina | Taal | Formaat | Alt-tekst |
|---|---|---|---|---|
| home-nl.png | https://bertvandewiel.nl/ | Nederlands | 1200 × 630 PNG (221 KB) | Startpagina van Bert van de Wiel met klok, live buienradar, alarmstatus en app-iconen |

Bron: `bron/og.html` (sjabloon) en `bron/render.py` (Playwright-render). Op de site staat de afbeelding in `web/og/home-nl.png`.
