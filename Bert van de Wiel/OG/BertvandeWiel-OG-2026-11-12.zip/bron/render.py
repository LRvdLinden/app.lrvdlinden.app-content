from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch()
    pg=b.new_page(viewport={"width":1200,"height":630}); pg.goto("file:///tmp/ogsrc/og.html"); pg.wait_for_timeout(400)
    pg.screenshot(path="/tmp/ogsrc/home-nl-raw.png")
    for s,out in [(512,"assets/icon-512.png"),(192,"assets/icon-192.png"),(180,"apple-touch-icon.png"),(32,"assets/favicon-32.png"),(48,"/tmp/ogsrc/f48.png")]:
        q=b.new_page(viewport={"width":s,"height":s}); q.goto("file:///tmp/ogsrc/icon.html"); q.wait_for_timeout(200)
        q.screenshot(path=out if out.startswith("/") else "/tmp/bvdw/web/"+out, omit_background=True)
    b.close()
