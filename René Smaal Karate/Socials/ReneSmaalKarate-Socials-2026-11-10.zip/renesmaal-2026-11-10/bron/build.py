#!/usr/bin/env python3
"""Rendert de social banners voor René Smaal Karate (renesmaal.nl) naar PNG."""
import base64, os, sys
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).parent
OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "out"
LOGO = ROOT / "assets" / "logo.svg"
OUT.mkdir(parents=True, exist_ok=True)

def font(name, weight):
    p = ROOT / "fonts" / f"fontsource-{name}-5.3.0/files/{name}-latin-{weight}-normal.woff2"
    return base64.b64encode(p.read_bytes()).decode()

FONTS = "".join(
    f"@font-face{{font-family:'{fam}';font-weight:{w};src:url(data:font/woff2;base64,{font(n, w)}) format('woff2');}}"
    for fam, n in [("Barlow", "barlow"), ("Barlow Condensed", "barlow-condensed")]
    for w in (400, 600, 700, 800)
)

if LOGO.exists():
    LOGO_SRC = "data:image/svg+xml;base64," + base64.b64encode(LOGO.read_bytes()).decode()
    def logo(size):
        return f'<img class="logo" src="{LOGO_SRC}" style="width:{size}px;height:{size}px">'
else:  # tijdelijke placeholder tot het echte logo er is
    def logo(size):
        return (f'<div class="logo ph" style="width:{size}px;height:{size}px;font-size:{size*0.28}px">RSK</div>')

NAVY, BLUE, CREAM = "#0F1848", "#243770", "#EDF0E3"

BASE = f"""
{FONTS}
*{{margin:0;padding:0;box-sizing:border-box}}
body{{width:var(--w);height:var(--h);overflow:hidden;font-family:'Barlow',sans-serif;color:#fff;
  background:radial-gradient(circle at 78% 18%, {BLUE} 0%, {NAVY} 62%);position:relative}}
.ring{{position:absolute;border-radius:50%;border:2px solid rgba(255,255,255,.14)}}
.ring.b{{border-width:1px;border-color:rgba(237,240,227,.10)}}
.logo{{display:block;border-radius:50%;box-shadow:0 0 0 3px rgba(255,255,255,.9),0 18px 50px rgba(0,0,0,.35)}}
.ph{{background:{BLUE};display:flex;align-items:center;justify-content:center;font-family:'Barlow Condensed';font-weight:800;letter-spacing:.05em}}
.kick{{font-weight:700;text-transform:uppercase;letter-spacing:.18em;color:{CREAM};opacity:.85}}
h1{{font-family:'Barlow Condensed';font-weight:800;text-transform:uppercase;line-height:.92;letter-spacing:.005em}}
h1 em{{font-style:normal;color:{CREAM}}}
.sub{{font-weight:400;color:rgba(255,255,255,.88);line-height:1.3}}
.cta{{display:inline-flex;align-items:center;gap:.6em;background:#fff;color:{NAVY};font-weight:700;border-radius:999px}}
.cta .arr{{font-weight:800}}
.url{{font-weight:600;letter-spacing:.04em;color:{CREAM}}}
.chips{{display:flex;flex-wrap:wrap}}
.chip{{border:2px solid rgba(255,255,255,.35);border-radius:999px;font-weight:600;color:#fff;white-space:nowrap}}
.chip b{{color:{CREAM};font-weight:700}}
.rule{{height:4px;background:{CREAM};border-radius:2px}}
"""

GROUPS = [("Little Ninja's", "3–6 jr"), ("Jeugd", "7–15 jr"), ("Karate", "volwassenen"), ("Boksen", "volwassenen")]

def chips(fs, pad, gap):
    return (f'<div class="chips" style="gap:{gap}px">' + "".join(
        f'<span class="chip" style="font-size:{fs}px;padding:{pad*0.55}px {pad}px">{n} <b>{a}</b></span>' for n, a in GROUPS)
        + "</div>")

def rings(cx, cy, radii):
    return "".join(
        f'<div class="ring{" b" if i % 2 else ""}" style="width:{r*2}px;height:{r*2}px;left:{cx-r}px;top:{cy-r}px"></div>'
        for i, r in enumerate(radii))

BANNERS = {}

# 1. Instagram/Facebook post vierkant
BANNERS["instagram-facebook-post-1080x1080"] = (1080, 1080, f"""
{rings(900, 180, [260, 360, 470])}
<div style="position:absolute;left:84px;top:84px">{logo(150)}</div>
<div style="position:absolute;left:84px;right:84px;top:330px">
  <div class="kick" style="font-size:26px;margin-bottom:22px">Karate in Apeldoorn</div>
  <h1 style="font-size:132px">Karate voor<br><em>jong en oud</em></h1>
  <div class="rule" style="width:120px;margin:40px 0 34px"></div>
  {chips(30, 26, 14)}
</div>
<div style="position:absolute;left:84px;right:84px;bottom:84px;display:flex;align-items:center;justify-content:space-between">
  <span class="cta" style="font-size:32px;padding:22px 36px">Vraag een proefles aan <span class="arr">→</span></span>
  <span class="url" style="font-size:30px">renesmaal.nl</span>
</div>""")

# 2. Instagram/Facebook post staand
BANNERS["instagram-facebook-post-1080x1350"] = (1080, 1350, f"""
{rings(880, 230, [280, 390, 510])}
<div style="position:absolute;left:84px;top:96px">{logo(170)}</div>
<div style="position:absolute;left:84px;right:84px;top:380px">
  <div class="kick" style="font-size:27px;margin-bottom:24px">René Smaal Karate</div>
  <h1 style="font-size:128px">Samen op weg<br>naar nieuwe<br><em>kampioenen</em></h1>
  <p class="sub" style="font-size:38px;margin-top:40px;max-width:820px">Bouw aan zelfvertrouwen en discipline, met plezier op de mat.</p>
  <div style="margin-top:44px">{chips(30, 26, 14)}</div>
</div>
<div style="position:absolute;left:84px;right:84px;bottom:96px;display:flex;align-items:center;justify-content:space-between">
  <span class="cta" style="font-size:33px;padding:24px 38px">Vraag een proefles aan <span class="arr">→</span></span>
  <span class="url" style="font-size:30px">renesmaal.nl</span>
</div>""")

# 3. Story / Reels cover (veilige zone 250px boven en onder)
BANNERS["story-reels-1080x1920"] = (1080, 1920, f"""
{rings(540, 500, [290, 410, 550])}
<div style="position:absolute;left:0;right:0;top:300px;display:flex;justify-content:center">{logo(400)}</div>
<div style="position:absolute;left:90px;right:90px;top:820px;text-align:center">
  <div class="kick" style="font-size:30px;margin-bottom:26px">Karate &amp; boksen in Apeldoorn</div>
  <h1 style="font-size:150px">Kom een<br><em>proefles</em> doen</h1>
  <div style="margin:46px auto 0;display:flex;justify-content:center">{chips(32, 28, 16).replace('class="chips"', 'class="chips" style="justify-content:center;gap:16px"', 1)}</div>
</div>
<div style="position:absolute;left:0;right:0;bottom:330px;text-align:center">
  <span class="cta" style="font-size:38px;padding:28px 50px">renesmaal.nl/proefles <span class="arr">→</span></span>
</div>""")

# 4. LinkedIn post
BANNERS["linkedin-post-1200x627"] = (1200, 627, f"""
{rings(1010, 313, [190, 270, 360])}
<div style="position:absolute;right:900px;"></div>
<div style="position:absolute;right:130px;top:183px">{logo(260)}</div>
<div style="position:absolute;left:80px;top:78px;width:660px">
  <div class="kick" style="font-size:20px;margin-bottom:18px">Stichting RSK · Apeldoorn</div>
  <h1 style="font-size:84px">Karate is meer<br>dan <em>een sport</em></h1>
  <p class="sub" style="font-size:26px;margin-top:24px;max-width:600px">Zelfvertrouwen, discipline en plezier. Voor kinderen vanaf 3 jaar, jeugd en volwassenen.</p>
</div>
<div style="position:absolute;left:80px;bottom:72px;display:flex;align-items:center;gap:28px">
  <span class="cta" style="font-size:24px;padding:16px 28px">Vraag een proefles aan <span class="arr">→</span></span>
  <span class="url" style="font-size:22px">renesmaal.nl</span>
</div>""")

# 5. Facebook cover (inhoud gecentreerd)
BANNERS["facebook-cover-1640x624"] = (1640, 624, f"""
{rings(820, 312, [330, 450, 600, 760])}
<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;gap:56px">
  {logo(230)}
  <div>
    <div class="kick" style="font-size:22px;margin-bottom:16px">René Smaal Karate · Apeldoorn</div>
    <h1 style="font-size:96px">Samen op weg naar<br>nieuwe <em>kampioenen</em></h1>
    <div class="url" style="font-size:26px;margin-top:22px">renesmaal.nl</div>
  </div>
</div>""")

# 6. LinkedIn cover (profielfoto valt links-onder; inhoud rechts)
BANNERS["linkedin-cover-1584x396"] = (1584, 396, f"""
{rings(1300, 198, [170, 250, 340])}
<div style="position:absolute;right:100px;top:0;bottom:0;display:flex;align-items:center;gap:44px">
  <div style="text-align:right">
    <div class="kick" style="font-size:19px;margin-bottom:12px">Karate &amp; boksen · Apeldoorn</div>
    <h1 style="font-size:72px">Samen op weg naar<br>nieuwe <em>kampioenen</em></h1>
    <div class="url" style="font-size:22px;margin-top:14px">renesmaal.nl</div>
  </div>
  {logo(200)}
</div>""")

with sync_playwright() as p:
    browser = p.chromium.launch()
    for name, (w, h, body) in BANNERS.items():
        page = browser.new_page(viewport={"width": w, "height": h}, device_scale_factor=1)
        page.set_content(f"<!doctype html><html lang='nl'><head><meta charset='utf-8'><style>:root{{--w:{w}px;--h:{h}px}}{BASE}</style></head><body>{body}</body></html>")
        page.evaluate("document.fonts.ready")
        page.wait_for_timeout(200)
        page.screenshot(path=str(OUT / f"{name}.png"))
        page.close()
        print("ok", name)
    browser.close()
