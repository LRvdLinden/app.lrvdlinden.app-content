# René Smaal Karate — social posts (NL)

Doel: algemene promotie · Website: https://renesmaal.nl · Proefles: https://renesmaal.nl/proefles

---

## Instagram / Facebook — post 1080×1080

**Afbeelding:** `instagram-facebook-post-1080x1080.png`

**Tekst:**
Karate is voor iedereen! 🥋 Bij René Smaal Karate in Apeldoorn train je op je eigen niveau: van Little Ninja's (3–6 jaar) en jeugd (7–15 jaar) tot karate en boksen voor volwassenen. Benieuwd of het iets voor jou of je kind is? Vraag een proefles aan via renesmaal.nl/proefles.

#karate #apeldoorn #karateapeldoorn #sportenapeldoorn #proefles #renesmaalkarate

**Alt-tekst:** Donkerblauwe banner van René Smaal Karate met de tekst "Karate voor jong en oud", de lesgroepen Little Ninja's 3–6 jaar, Jeugd 7–15 jaar, Karate volwassenen en Boksen volwassenen, en de knop "Vraag een proefles aan" met renesmaal.nl.

---

## Instagram / Facebook — post 1080×1350

**Afbeelding:** `instagram-facebook-post-1080x1350.png`

**Tekst:**
Samen op weg naar nieuwe kampioenen. 💪 Bij Stichting RSK bouwen we aan zelfvertrouwen en discipline, en dat met veel plezier op de mat. Of je nu 3 bent of 63: er is een groep die bij je past. Kom een keer meetrainen!

👉 renesmaal.nl/proefles

#karate #apeldoorn #zelfvertrouwen #discipline #jeugdsport #renesmaalkarate

**Alt-tekst:** Staande banner van René Smaal Karate met de kop "Samen op weg naar nieuwe kampioenen", de tekst "Bouw aan zelfvertrouwen en discipline, met plezier op de mat", vier lesgroepen en de knop "Vraag een proefles aan".

---

## Story / Reels — 1080×1920

**Afbeelding:** `story-reels-1080x1920.png`

**Tekst (sticker/link):** Link-sticker naar https://renesmaal.nl/proefles met de tekst "Proefles aanvragen".

**Alt-tekst:** Story-afbeelding met het logo van René Smaal Karate, de tekst "Kom een proefles doen", de groepen Little Ninja's, Jeugd, Karate volwassenen en Boksen volwassenen, en de link renesmaal.nl/proefles.

---

## LinkedIn — post 1200×627

**Afbeelding:** `linkedin-post-1200x627.png`

**Tekst:**
Karate is meer dan een sport. Bij Stichting RSK in Apeldoorn leren kinderen, jongeren en volwassenen wat zelfvertrouwen, discipline en respect in de praktijk betekenen. Onder leiding van René Smaal (5e Dan) trainen leden in breedte- én topsport, van Little Ninja's vanaf 3 jaar tot zwarte band. Wil je zelf ervaren wat karate of boksen je brengt? Vraag een proefles aan via https://renesmaal.nl/proefles.

Ook als bedrijf kun je bijdragen: lees meer over sponsoring op https://renesmaal.nl/sponsors/word-sponsor.

**Alt-tekst:** Liggende banner van Stichting RSK Apeldoorn met de kop "Karate is meer dan een sport", de tekst "Zelfvertrouwen, discipline en plezier. Voor kinderen vanaf 3 jaar, jeugd en volwassenen", het logo van René Smaal Karate en de knop "Vraag een proefles aan".

---

## Facebook-cover — 1640×624

**Afbeelding:** `facebook-cover-1640x624.png`

**Alt-tekst:** Coverafbeelding met het logo van René Smaal Karate en de tekst "Samen op weg naar nieuwe kampioenen" met renesmaal.nl.

---

## LinkedIn-cover — 1584×396

**Afbeelding:** `linkedin-cover-1584x396.png`
Inhoud staat rechts, zodat de profielfoto linksonder niets afdekt.

**Alt-tekst:** Bannerafbeelding met de tekst "Karate & boksen · Apeldoorn — Samen op weg naar nieuwe kampioenen", renesmaal.nl en het logo van René Smaal Karate.
